package com.davicut.ia

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast

class MainActivity : Activity() {
    private val blue = Color.rgb(22, 139, 255)
    private val dark = Color.rgb(7, 11, 19)
    private val panel = Color.rgb(17, 27, 43)
    private lateinit var preview: VideoView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(dark)
        }

        val brand = TextView(this).apply {
            text = "DAVI CUT IA"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            letterSpacing = 0.04f
        }
        root.addView(brand, matchWrap())

        val tagline = TextView(this).apply {
            text = "SEU ESTÚDIO DE VÍDEOS COM IA"
            textSize = 12f
            setTextColor(blue)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 22)
            letterSpacing = 0.12f
        }
        root.addView(tagline, matchWrap())

        val create = makeButton("✨  CRIAR VÍDEO NA DOLA IA")
        create.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.dola.com/download"))
            try { startActivity(intent) }
            catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir a Dola.", Toast.LENGTH_LONG).show() }
        }
        root.addView(create, matchWrap())

        val import = makeButton("＋  IMPORTAR VÍDEO OU FOTO")
        import.setOnClickListener {
            val picker = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("video/*", "image/*"))
            }
            startActivityForResult(picker, 101)
        }
        root.addView(import, matchWrap())

        val section = TextView(this).apply {
            text = "PRÉ-VISUALIZAÇÃO"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(2, 22, 2, 10)
        }
        root.addView(section, matchWrap())

        preview = VideoView(this).apply {
            setBackgroundColor(panel)
        }
        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 230
        ))

        status = TextView(this).apply {
            text = "Nenhum vídeo selecionado"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(2, 12, 2, 12)
        }
        root.addView(status, matchWrap())

        val edit = makeButton("✂  ÁREA DE EDIÇÃO")
        edit.setOnClickListener {
            Toast.makeText(this, "A edição avançada será adicionada na próxima versão.", Toast.LENGTH_LONG).show()
        }
        root.addView(edit, matchWrap())

        val note = TextView(this).apply {
            text = "Dica: crie seu vídeo na Dola, salve no celular e importe aqui para assistir."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(4, 18, 4, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(blue)
        setPadding(12, 16, 12, 16)
        stateListAnimator = null
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 12 }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val type = contentResolver.getType(uri) ?: ""
            if (type.startsWith("video/")) {
                preview.setVideoURI(uri)
                preview.setOnPreparedListener { it.isLooping = true; preview.start() }
                status.text = "Vídeo carregado com sucesso"
            } else if (type.startsWith("image/")) {
                status.text = "Imagem selecionada. Prévia de imagem será adicionada na próxima versão."
                Toast.makeText(this, "Imagem importada.", Toast.LENGTH_SHORT).show()
            } else {
                status.text = "Arquivo selecionado"
            }
        }
    }
}
